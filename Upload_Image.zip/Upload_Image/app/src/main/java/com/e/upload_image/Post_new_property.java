package com.e.upload_image;


import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.Spinner;

import androidx.appcompat.app.AppCompatActivity;


public class Post_new_property extends AppCompatActivity implements AdapterView.OnItemSelectedListener {
    Spinner spinner;
    Button btn;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_post_new_property);
        getSupportActionBar().setTitle("Post new Property");
        spinner = findViewById(R.id.spinner1);
        btn = findViewById(R.id.savebtn2);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setDisplayShowHomeEnabled(true);//for back icon..
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(Post_new_property.this,Search_Location.class));
                Log.e("Post new","to search" );
            }
        });
        spinner.setOnItemSelectedListener(this);
    }

        //Upload image..


        @Override
        public void onItemSelected (AdapterView < ? > adapterView, View view,int i, long l){

        }

        @Override
        public void onNothingSelected (AdapterView < ? > adapterView){

        }
}
