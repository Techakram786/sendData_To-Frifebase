package com.e.upload_image;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;

import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.tabs.TabLayout;

public class MainActivity extends AppCompatActivity {
    TabLayout tabLayout;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        getSupportActionBar().setTitle("Home_Page");
        tabLayout=findViewById(R.id.myTab);
       // viewPager=findViewById(R.id.viewpager);
        tabLayout.addTab(tabLayout.newTab().setText("Rent"));
        tabLayout.addTab(tabLayout.newTab().setText("Buy"));

    }
    public void Owners_btn(View view){
        startActivity(new Intent(this,Post_new_property.class));
        Log.e("Mainactivity","main" );
    }
}